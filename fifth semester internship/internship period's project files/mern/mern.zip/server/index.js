import express from 'express';
import mongoose from "mongoose";

const app= express();
const port = 3000;
// app.get("/test", (req,res)=>{ 
//     res.send("success");
// })
let string = "mongodb+srv://albincl128:albincl128@jackerman.rludzjt.mongodb.net/?retryWrites=true&w=majority&appName=jackerman"; 
mongoose.connect(string)
.then(()=>{
    console.log("mongodb connected");
})
.catch((err)=>{
    console.log("mongodb connectionerror :",err);
})
app.listen(port,(req,res)=>{
    console.log(`server is running on port http://localhost:${port}`);
})